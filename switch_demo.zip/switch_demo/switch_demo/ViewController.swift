//
//  ViewController.swift
//  switch_demo
//
//  Created by MAC on 31/05/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgicon: UIImageView!
    @IBOutlet var s1: UIView!
    @IBOutlet weak var lb: UILabel!
    override func viewDidLoad() {

        super.viewDidLoad()
        
        //imgicon.image = UIImage(named: "ab")
        let im1 = UIImage(named: "ab")
        // change icon coloe in below two line
        imgicon.image = im1?.withRenderingMode(.alwaysTemplate)
        imgicon.tintColor = UIColor.red
        
        let switchDemo=UISwitch(frame:CGRect(x: 150, y: 150, width: 0, height: 0))
        switchDemo.transform = CGAffineTransform(scaleX: 2.0, y: 2.0)
        switchDemo.backgroundColor = UIColor.blue
        switchDemo.thumbTintColor = UIColor.red
        switchDemo.onTintColor = UIColor.gray
        switchDemo.addTarget(self, action: #selector(self.switchStateDidChange(_:)), for: .valueChanged)
        switchDemo.setOn(true, animated: false)
        self.view.addSubview(switchDemo)
        
        var imageView : UIImageView
        imageView  = UIImageView(frame:CGRect(x: 10, y: 450, width: 100, height: 100));
        imageView.image = UIImage(named:"abc")
        imageView.layer.borderWidth = 1.0
        //imageView.isUserInteractionEnabled = true
         self.view.addSubview(imageView)
        
        let img1 = UIImage(named: "abc")!
        let img2 = UIImage(named: "red")!
        let img3 = UIImage(named: "green")!
        let animatedImage = UIImage.animatedImage(with: [img1, img2, img3], duration: 1.0)
        var imageView1: UIImageView = UIImageView(image: animatedImage)
        imageView1  = UIImageView(frame:CGRect(x: 100, y: 500, width: 100, height: 100));
        view.addSubview(imageView1)
        
        let imageV = UIImageView(frame: CGRect(x: 150, y: 450, width: 50, height: 50))
      //  imageV.center = view.center
        imageV.layer.borderWidth = 2.0
        imageV.image = UIImage(named: "red", in: Bundle(for: type(of: self)), compatibleWith: nil)
        view.addSubview(imageV)
        // Scaling
        UIView.animate(withDuration: 6.0, animations: {
            imageV.transform = CGAffineTransform(scaleX: 2, y: 2)
        })
        // Do any additional setup after loading the view.
    }
    
    @objc func switchStateDidChange(_ sender:UISwitch){
        if (sender.isOn == true){
            lb.text = "Switch is On"
            print("UISwitch state is now ON")
        }
        else{
            lb.text = "Switch is Off"
            print("UISwitch state is now Off")
        }
    }
}

